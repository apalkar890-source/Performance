"""Android-safe, standard-library-only system metrics for the Kivy mobile edition."""
from __future__ import annotations

import os
import platform
import time


def _read_cpu_ticks():
    try:
        with open("/proc/stat", "r", encoding="ascii") as stream:
            parts = stream.readline().split()
        values = [int(value) for value in parts[1:]]
        idle = values[3] + (values[4] if len(values) > 4 else 0)
        total = sum(values)
        return total, idle
    except (OSError, ValueError, IndexError):
        return None


def read_memory():
    values = {}
    try:
        with open("/proc/meminfo", "r", encoding="ascii") as stream:
            for line in stream:
                if ":" not in line:
                    continue
                key, rest = line.split(":", 1)
                fields = rest.split()
                if fields:
                    values[key] = int(fields[0]) * 1024
    except (OSError, ValueError):
        return {"total": 0, "available": 0, "used": 0, "percent": 0.0}
    total = values.get("MemTotal", 0)
    available = values.get("MemAvailable", values.get("MemFree", 0) + values.get("Buffers", 0) + values.get("Cached", 0))
    used = max(0, total - available)
    return {"total": total, "available": available, "used": used,
            "percent": (used / total * 100) if total else 0.0}


def read_storage():
    # Prefer shared internal storage on Android; fall back to the app-visible data volume.
    candidates = ("/storage/emulated/0", "/data", "/")
    for path in candidates:
        try:
            if not os.path.exists(path):
                continue
            stats = os.statvfs(path)
            total = stats.f_blocks * stats.f_frsize
            free = stats.f_bavail * stats.f_frsize
            used = max(0, total - free)
            if total:
                return {"total": total, "free": free, "used": used,
                        "percent": (used / total * 100), "path": path}
        except (OSError, AttributeError):
            continue
    return {"total": 0, "free": 0, "used": 0, "percent": 0.0, "path": "Unavailable"}


def read_uptime():
    try:
        with open("/proc/uptime", "r", encoding="ascii") as stream:
            seconds = int(float(stream.read().split()[0]))
        days, rem = divmod(seconds, 86400)
        hours, rem = divmod(rem, 3600)
        minutes, _ = divmod(rem, 60)
        return f"{days}d {hours}h {minutes}m"
    except (OSError, ValueError, IndexError):
        return "Not available"


def snapshot(previous_cpu=None):
    current = _read_cpu_ticks()
    cpu_percent = None
    if current and previous_cpu:
        total_delta = current[0] - previous_cpu[0]
        idle_delta = current[1] - previous_cpu[1]
        if total_delta > 0:
            cpu_percent = max(0.0, min(100.0, (total_delta - idle_delta) / total_delta * 100.0))
    return {
        "cpu_percent": cpu_percent,
        "cpu_ticks": current,
        "memory": read_memory(),
        "storage": read_storage(),
        "device": platform.machine() or "Android device",
        "os": f"{platform.system()} {platform.release()}",
        "uptime": read_uptime(),
    }


def human_bytes(value):
    amount = float(max(0, value))
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if amount < 1024 or unit == "TB":
            return f"{amount:.1f} {unit}" if unit != "B" else f"{int(amount)} B"
        amount /= 1024
    return f"{amount:.1f} TB"
