# NEXUS OPTIMIZER — Android edition

This is the Android/Kivy companion app. It displays CPU load, memory, internal storage volume capacity and device uptime. The app uses only the Python standard library plus Kivy and asks for no Android runtime permissions.

Android intentionally does not expose the same controls as a desktop OS. This app cannot close other apps, clear another app's data, manage Android services or clean private/system storage. Those controls are not simulated.

## Build a debug APK

Buildozer runs on Linux/macOS; on Windows, use WSL2. Use Python 3.12 in a virtual environment, Java 17 and the packages listed in the top-level README. Then:

```bash
python -m pip install --upgrade buildozer setuptools Cython==0.29.34
buildozer -v android debug
```

The debug APK is written to `bin/`. The first build downloads the Android SDK/NDK. The project configuration targets API 36, minimum API 24, NDK 28c and ARM64/ARMv7 devices.

Alternatively, push the project to GitHub and run the **Build Android APK** workflow under the Actions tab. The generated APK is uploaded as a workflow artifact.
