__version__ = "1.0.0"

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.progressbar import ProgressBar
from kivy.uix.scrollview import ScrollView
from kivy.uix.widget import Widget

from metrics import snapshot, human_bytes


BG = (0.035, 0.063, 0.125, 1)
PANEL = (0.078, 0.12, 0.21, 1)
ACCENT = (0.33, 0.47, 0.93, 1)
TEXT = (0.91, 0.94, 1, 1)
MUTED = (0.57, 0.63, 0.75, 1)


class MetricCard(BoxLayout):
    def __init__(self, title, **kwargs):
        super().__init__(orientation="vertical", padding=dp(14), spacing=dp(7), **kwargs)
        self.size_hint_y = None
        self.height = dp(132)
        self.canvas.before.clear()
        from kivy.graphics import Color, RoundedRectangle
        with self.canvas.before:
            Color(*PANEL)
            self._background = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(14)])
        self.bind(pos=self._update_background, size=self._update_background)
        title_label = Label(text=title, color=MUTED, bold=True, font_size="11sp", halign="left", valign="middle", size_hint_y=None, height=dp(20))
        title_label.bind(size=lambda widget, size: setattr(widget, "text_size", size))
        self.add_widget(title_label)
        self.value_label = Label(text="—", color=TEXT, bold=True, font_size="25sp", halign="left", valign="middle", size_hint_y=None, height=dp(38))
        self.value_label.bind(size=lambda widget, size: setattr(widget, "text_size", size))
        self.add_widget(self.value_label)
        self.detail_label = Label(text="Waiting for reading", color=MUTED, font_size="11sp", halign="left", valign="top")
        self.detail_label.bind(size=lambda widget, size: setattr(widget, "text_size", size))
        self.add_widget(self.detail_label)

    def _update_background(self, *_):
        self._background.pos = self.pos
        self._background.size = self.size

    def update_value(self, value, detail):
        self.value_label.text = value
        self.detail_label.text = detail


class NexusMobile(App):
    def build(self):
        Window.clearcolor = BG
        self.last_cpu = None
        self.root_layout = BoxLayout(orientation="vertical", padding=(dp(16), dp(12)), spacing=dp(10))
        header = BoxLayout(orientation="vertical", size_hint_y=None, height=dp(88), spacing=dp(3))
        header.add_widget(Label(text="NEXUS OPTIMIZER", color=TEXT, bold=True, font_size="21sp", halign="left", valign="middle", size_hint_y=None, height=dp(35), text_size=(Window.width - dp(32), None)))
        header.add_widget(Label(text="MOBILE SYSTEM OVERVIEW", color=MUTED, font_size="10sp", halign="left", valign="middle", size_hint_y=None, height=dp(20), text_size=(Window.width - dp(32), None)))
        self.root_layout.add_widget(header)

        scroll = ScrollView(do_scroll_x=False)
        content = BoxLayout(orientation="vertical", spacing=dp(12), size_hint_y=None, padding=(0, 0, 0, dp(12)))
        content.bind(minimum_height=content.setter("height"))
        intro = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(6), size_hint_y=None, height=dp(105))
        from kivy.graphics import Color, RoundedRectangle
        with intro.canvas.before:
            Color(0.11, 0.16, 0.30, 1)
            self.hero_bg = RoundedRectangle(pos=intro.pos, size=intro.size, radius=[dp(14)])
        intro.bind(pos=lambda w, *_: setattr(self.hero_bg, "pos", w.pos), size=lambda w, *_: setattr(self.hero_bg, "size", w.size))
        intro.add_widget(Label(text="Your device at a glance", color=TEXT, bold=True, font_size="16sp", halign="left", valign="middle", size_hint_y=None, height=dp(28)))
        intro.add_widget(Label(text="Live CPU, memory and storage readings available to this app.", color=MUTED, font_size="11sp", halign="left", valign="top"))
        content.add_widget(intro)

        grid = GridLayout(cols=2, spacing=dp(10), size_hint_y=None)
        grid.bind(minimum_height=grid.setter("height"))
        self.cards = {
            "cpu": MetricCard("CPU USAGE"),
            "memory": MetricCard("MEMORY (RAM)"),
            "storage": MetricCard("DEVICE STORAGE"),
            "uptime": MetricCard("DEVICE UPTIME"),
        }
        for card in self.cards.values():
            grid.add_widget(card)
        content.add_widget(grid)

        device_box = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(6), size_hint_y=None, height=dp(100))
        with device_box.canvas.before:
            Color(*PANEL)
            device_bg = RoundedRectangle(pos=device_box.pos, size=device_box.size, radius=[dp(14)])
        device_box.bind(pos=lambda w, *_: setattr(device_bg, "pos", w.pos), size=lambda w, *_: setattr(device_bg, "size", w.size))
        device_box.add_widget(Label(text="DEVICE", color=TEXT, bold=True, font_size="12sp", halign="left", size_hint_y=None, height=dp(20)))
        self.device_label = Label(text="Loading device information…", color=MUTED, font_size="11sp", halign="left", valign="top")
        self.device_label.bind(size=lambda widget, size: setattr(widget, "text_size", size))
        device_box.add_widget(self.device_label)
        content.add_widget(device_box)

        self.status = Label(text="Monitoring updates every 3 seconds.", color=MUTED, font_size="10sp", size_hint_y=None, height=dp(25), halign="left")
        content.add_widget(self.status)
        scroll.add_widget(content)
        self.root_layout.add_widget(scroll)

        controls = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        refresh = Button(text="Refresh now", background_normal="", background_color=ACCENT, color=(1, 1, 1, 1), bold=True)
        refresh.bind(on_release=lambda *_: self.refresh_metrics())
        controls.add_widget(refresh)
        self.root_layout.add_widget(controls)
        self.refresh_metrics()
        Clock.schedule_interval(lambda _dt: self.refresh_metrics(), 3.0)
        return self.root_layout

    def refresh_metrics(self):
        try:
            data = snapshot(self.last_cpu)
            self.last_cpu = data["cpu_ticks"]
            cpu = data["cpu_percent"]
            self.cards["cpu"].update_value(f"{cpu:.1f}%" if cpu is not None else "…", "Processor load (sampled)")
            mem = data["memory"]
            self.cards["memory"].update_value(f"{mem['percent']:.1f}%", f"{human_bytes(mem['used'])} / {human_bytes(mem['total'])} used")
            disk = data["storage"]
            self.cards["storage"].update_value(f"{disk['percent']:.1f}%", f"{human_bytes(disk['free'])} free · {disk.get('path', 'device')} volume")
            self.cards["uptime"].update_value(data["uptime"], "Since last device boot")
            self.device_label.text = f"{data['device']} · {data['os']}\nUpdated at {__import__('time').strftime('%H:%M:%S')}"
            self.status.text = "Readings updated · No system changes are made by this app."
        except Exception as exc:
            self.status.text = f"Metrics unavailable: {exc}"


if __name__ == "__main__":
    NexusMobile().run()
