# Build handoff status

- Desktop source and packaging scripts: prepared.
- Android/Kivy source and Buildozer configuration: prepared.
- Core automated tests: passed (6 tests).
- Desktop UI runtime smoke test: not run in the build container because PySide6 was unavailable and package downloads could not reach the package index.
- Windows `.exe`: not generated; PyInstaller must package on Windows itself.
- Android `.apk`: not generated here because Buildozer and the Android SDK/NDK were not installed and could not be downloaded. Use `build_android.sh` in Linux/WSL or run the included GitHub Actions workflow to generate a debug APK.

No placeholder or dummy APK/EXE is included.
