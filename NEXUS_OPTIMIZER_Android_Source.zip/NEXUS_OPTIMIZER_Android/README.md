# NEXUS OPTIMIZER — Complete Project

NEXUS OPTIMIZER is a small system-monitoring and maintenance assistant with two separate front ends:

- **Desktop / laptop:** PySide6 application for Windows 10/11, macOS and Linux.
- **Android:** Kivy app project that can be built into an APK with Buildozer.

The desktop edition preserves the original dark NEXUS look while adding real system readings and usable tools. The mobile edition is intentionally a lightweight device overview, not a root-level optimizer.

## Desktop features

- Live CPU, RAM and primary-volume usage, with a configurable 1–5 second refresh interval.
- RAM Optimizer process list, sorted by memory usage. A user can request a normal process close after confirmation. NEXUS will not force-kill it or close protected system processes.
- PC Cleaner scan and preview for regular files at least 24 hours old in the operating system's temporary directory. The user must select files and confirm; selected files are moved to the recycle bin / trash via `Send2Trash`.
- Storage Analyzer for mounted volumes and folder-size inspection. Symbolic links are not followed.
- GPU Monitor reads NVIDIA telemetry when `nvidia-smi` is installed. Other GPU vendors may not expose metrics through this build.
- Performance / device information and active power plan (read-only).
- Startup Manager lists supported startup entries but does not edit them in this version.
- Scrollable pages and a compact minimum window size for smaller laptop displays.

### Desktop setup (Windows PowerShell)

Install Python 3.10 or newer, then open PowerShell in the `NexusOptimizer` folder:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

If script activation is blocked, use this in the same PowerShell window:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

### Desktop setup (macOS / Linux)

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py
```

### Build a laptop executable

- Windows: double-click `build_windows.bat`.
- Linux: run `chmod +x build_linux.sh && ./build_linux.sh`.
- macOS: use the Linux build commands from a macOS terminal; PyInstaller will create a macOS application bundle on macOS itself.

The packaged output is placed in `dist/`. Build the executable on the operating system you intend to run it on; PyInstaller is not a cross-compiler.

## Android APK

The Android frontend is in `mobile/`. It uses Kivy and the Python standard library to show CPU, RAM, storage and uptime readings available to the app. Android's app sandbox does not let an ordinary app inspect/terminate other apps' processes or clean their private/system files, so those desktop-only actions are intentionally not offered on mobile.

### Build locally (Ubuntu / WSL2 recommended)

1. Install Java 17 and the Android build dependencies used by Buildozer.
2. Install Buildozer and Cython:

```bash
python3 -m pip install --user --upgrade buildozer Cython==0.29.36
```

3. Build the debug APK:

```bash
cd mobile
buildozer -v android debug
```

The APK will be created in `mobile/bin/`. First-time Android builds download the Android SDK/NDK and can take a while. The configured APK targets `arm64-v8a` and `armeabi-v7a` devices.

### Build APK with GitHub Actions

Push this project to a GitHub repository, open **Actions → Build Android APK → Run workflow**, and download the `nexus-optimizer-android-apk` artifact after the workflow succeeds. The workflow also runs on pushes that change files under `mobile/`.

## Run tests

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

## Safety and limitations

- Cleanup is restricted to the OS temp folder and only considers files older than 24 hours. It skips symbolic links, does not remove folders, and revalidates every path before moving it to trash.
- Process termination is opt-in, asks the OS for a normal close, and is never automatic. Save work before closing an application.
- Startup entries and power settings are shown read-only; the app does not edit registry values or system power plans.
- GPU telemetry depends on installed vendor tools and permissions.
- This is a system utility, not a guarantee of increased speed. It reports actual readings and avoids risky “RAM booster” tricks.

## Project layout

```text
NexusOptimizer/
├── main.py                       # convenient desktop launcher
├── nexus_core.py                 # cross-platform desktop system utilities
├── desktop/main.py               # PySide6 desktop UI
├── mobile/main.py                # Kivy Android UI
├── mobile/metrics.py             # Android-safe metrics (stdlib only)
├── mobile/buildozer.spec         # APK build configuration
├── tests/test_core.py
├── requirements.txt
├── requirements-build.txt
├── build_windows.bat
├── build_linux.sh
└── .github/workflows/android-apk.yml
```
