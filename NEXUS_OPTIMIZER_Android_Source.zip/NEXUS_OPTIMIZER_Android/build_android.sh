#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/mobile"
python3 -m pip install --user --upgrade buildozer Cython==0.29.34
buildozer -v android debug
echo "APK output: $(pwd)/bin/"
